const express = require("express");
const app = express();
const ServerPortRouter = express.Router();

const ServerPort = require("./app");
const ServerPort2 = require("./app1");
const ServerPort3 = require("./userpro");

ServerPortRouter.route("/Signup").post(function(req, res) {
  const serverport = new ServerPort(req.body);
  serverport
    .save()
    .then(serverport => {
      res.json("User added Successfully");
    })
    .catch(err => {
      res.status(400).send("unable to save to database");
    });
});

ServerPortRouter.route("/register").post(function(req, res) {
  const serverport = new ServerPort2(req.body);
  serverport
    .save()
    .then(serverport => {
      res.json("User added Successfully");
    })
    .catch(err => {
      res.status(400).send("unable to save to database");
    });
});
ServerPortRouter.route("/userprofile").post(function(req, res) {
  const serverport = new ServerPort3(req.body);
  serverport
    .save()
    .then(serverport => {
      res.json("User added Successfully");
    })
    .catch(err => {
      res.status(400).send("unable to save to database");
    });
});
// ServerPortRouter.route("/contacts").get(function(req, res) {
//   ServerPort.find(function(err, serverports) {
//     if (err) {
//       console.log(err);
//     } else {
//       res.json(serverports);
//     }
//   });
// });

ServerPortRouter.route("/Signup").get(function(req, res) {
  ServerPort.find(function(err, serverports) {
    if (err) {
      console.log(err);
    } else {
      res.json(serverports);
    }
  });
});

ServerPortRouter.route("/register").get(function(req, res) {
  ServerPort2.find(function(err, serverports) {
    if (err) {
      console.log(err);
    } else {
      res.json(serverports);
    }
  });
});
ServerPortRouter.route("/userprofile").get(function(req, res) {
  ServerPort3.find(function(err, serverports) {
    if (err) {
      console.log(err);
    } else {
      res.json(serverports);
    }
  });
});
ServerPortRouter.route("/getUserData/:id").get(function(req, res) {
  ServerPort3.findOne({ userid: req.params.id }, function(err, serverports) {
    if (err) {
      console.log(err);
    } else {
      res.json(serverports);
    }
  });
});
ServerPortRouter.route("/Signup/:id").get(function(req, res) {
  ServerPort.findOne({ 
    _id: req.params.id }, function(err, serverports) {
    if (err) {
      console.log(err);
    } else {
      console.log(serverports)
      res.json(serverports);
    }
  });
});

ServerPortRouter.route("/Edituserprofile/:id").put(function(req, res) {
  console.log(req.body);
  ServerPort3.findOneAndUpdate({ userid: req.params.id }, req.body, function(
    err,
    serverports
  ) {
    if (err) {
      console.log(err);
    } else {
      res.json(serverports);
    }
  }).catch(err => {
    res.status(400).send("unable to save to database");
  });
});
module.exports = ServerPortRouter;
