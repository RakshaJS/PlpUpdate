import React from "react";
import axios from "axios";
import { Redirect } from "react-router";
import Menu from "../core/Menu";
class Login extends React.Component {
  constructor(props) {
    super(props);

    this.onChangeUsername = this.onChangeUsername.bind(this);
    this.onChangePassword = this.onChangePassword.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
    this.state = {
      email: "",
      password: "",
      login: [],
      redirect: "",
      logeduser: "",
      logeduseredudetail: {
        school: "",
        college: "",
        degree: "",
        selectedValue: "",
        schoolyear: "",
        clgyear: "",
        degyear: "",
        location: "",
        skills: "",
        comname: "",
        yof: "",
        userid: ""
      },
      flag: false
    };
  }
  componentDidMount() {
    axios
      .get("http://localhost:3001/Signup")
      .then(response => {
        this.setState({
          login: response.data
        });
        console.log(this.login);
      })
      .catch(function(error) {
        console.log(error);
      });
  }
  onSubmit(e) {
    this.enteredUsername = this.state.email;
    this.enteredPassword = this.state.password;
    console.log(this.state.login.length);
    for (let i = 0; i < this.state.login.length; i++) {
      if (
        this.enteredUsername === this.state.login[i].email &&
        this.enteredPassword === this.state.login[i].password
      ) {
        this.setState({
          logeduser: this.state.login[i]._id,
          flag: true
        });
        axios
          .get("http://localhost:3001/getUserData/" + this.state.logeduser)
          .then(response => {
            console.log(response.data);
            this.setState({
              logeduseredudetail: response.data,
              redirect: true
            });
          })
          .catch(function(error) {
            console.log(error);
          });
        this.flag2 = true;
        break;
      } else {
        this.setState({
          flag: false,
          redirect: false
        });
        this.flag2 = false;
      }
    }
    console.log("value=>" + this.state.redirect);
    if (this.flag2 === false) {
      alert("Wrong username and password");
    }

    e.preventDefault();
  }
  onChangeUsername(e) {
    this.setState({
      email: e.target.value
    });
  }
  onChangePassword(e) {
    this.setState({
      password: e.target.value
    });
  }

  render() {
    const { redirect } = this.state;
    console.log("redirect value" + redirect);
    if (redirect) {
      sessionStorage.setItem("sessionId", this.state.logeduser);
      alert("Login Successfully");
      if (this.state.logeduseredudetail !== null) {
        return <Redirect to="/profileuser" />;
      } else {
        return <Redirect to="/userprofile" />;
      }
    }
    return (
      <div className="container">
        <Menu />
        <div className="col-lg-4">
          <br />
          <br />
          <h2 className="text-center text-primary">Welcome Back</h2>
          <form onSubmit={this.onSubmit}>
            <br />

            <div className="form-group">
              <label className="text-primary">
                <h3>
                  <i className="far fa-envelope" />
                  &nbsp;Email
                </h3>
              </label>
              <input
                type="text"
                className="form-control"
                placeholder="Email"
                value={this.state.email}
                onChange={this.onChangeUsername}
              />
            </div>
            <div className="form-group">
              <label className="text-primary">
                <h3>
                  <i className="fas fa-lock" />
                  &nbsp;Password{" "}
                </h3>
              </label>
              <input
                type="password"
                className="form-control"
                placeholder="Password"
                value={this.state.password}
                onChange={this.onChangePassword}
              />
            </div>

            <div className="form-group">
              <input type="submit" value="Signup" className="btn btn-primary" />
            </div>
          </form>
        </div>
      </div>
    );
  }
}

export default Login;
