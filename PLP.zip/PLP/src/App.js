import React from "react";
import Router from "./components/Router";
import { BrowserRouter } from "react-router-dom";
// import Menu from './components/core/Menu'

import "./App.css";

const App = () => (
  <div className="container">
    <BrowserRouter>
      {/* <Menu/> */}
      <Router />
    </BrowserRouter>
  </div>
);

export default App;
